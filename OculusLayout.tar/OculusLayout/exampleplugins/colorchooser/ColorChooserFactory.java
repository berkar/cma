import com.oculustech.layoutbuilder.pluginapi.*;

public class ColorChooserFactory implements ComponentFactory {
    private ComponentKind[] kinds = null;

    public ColorChooserFactory() { }

    public ComponentKind[] getComponentKinds() {
        if (kinds == null) {
            kinds = new ComponentKind[ColorChooserKind.kinds.length];
            System.arraycopy(ColorChooserKind.kinds,0,kinds,0,ColorChooserKind.kinds.length);
        }
        return kinds;
    }
}
