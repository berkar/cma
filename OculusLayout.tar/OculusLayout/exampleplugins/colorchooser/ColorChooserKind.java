import com.oculustech.layoutbuilder.pluginapi.*;
import javax.swing.*;

public class ColorChooserKind {

    public final static Icon colorChooserIcon = 
        new ImageIcon(ColorChooserKind.class.getResource("ColorChooser.png"));

    public final static Object[] kinds = 
        (new Object[] {
            (new DefaultComponentKind(JColorChooser.class, "JColorChooser",
                                      "JColorChooser", "Swing color chooser component",
                                      colorChooserIcon))
	});
}
