This directory contains example Builder plugins.
Builder plugins enable you to build applications using your 
own custom components in the Builder.  

Contents:

  colorchooser:  a plugin that adds the JColorChooser component to
    the builder.

