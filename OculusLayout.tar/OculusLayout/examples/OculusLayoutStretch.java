/*
 * Oculus Layout Tutorial
 */

import javax.swing.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import com.oculustech.layout.*;

public class OculusLayoutStretch extends JFrame {

    public OculusLayoutStretch() {
        super("OculusLayoutTutorial");

        // Create some components
        JLabel intLabel = new JLabel("int");
        JLabel doubleLabel = new JLabel("double");
        JLabel doubleLabel2 = new JLabel("double");
        JLabel longLengthLabel = new JLabel("reallyreallyreallyreallyreallylonglabel");
        JTextField intField = new JTextField(5);
        JTextField doubleField = new JTextField(5);
        JTextField doubleField2 = new JTextField(5);
        JTextArea textArea = new JTextArea();
        JButton submitButton = new JButton("Submit");


        // Lay the components out.  The top-level box will be vertically
        // oriented.
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);

        layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.blue, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.add(intLabel);
            // The first text field is added with the default stretching 
            // preferences - CAN_BE_STRETCHED horizontally and NO_STRETCH 
            // vertically.
            layout.add(intField);
            layout.add(doubleLabel);
            // The second and third text field are given higher stretching 
            // preferences - they want to be stretched horizontally.
            layout.add(doubleField, OculusLayoutInfo.WANT_STRETCHED, OculusLayoutInfo.NO_STRETCH);
            layout.add(doubleLabel2);
            layout.add(doubleField2, OculusLayoutInfo.WANT_STRETCHED, OculusLayoutInfo.NO_STRETCH);
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.red, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.green, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
                layout.add(longLengthLabel);
                // The text area is given a lower horizontal stretching
                // preference (STRETCH_ONLY_TO_ALIGN) than its default
                // (CAN_BE_STRETCHED).  Note that STRETCH_ONLY_TO_ALIGN is
                // applied to the auxiliary axis of the vertically-oriented
                // parent box.
                layout.add(textArea, OculusLayoutInfo.STRETCH_ONLY_TO_ALIGN, OculusLayoutInfo.CAN_BE_STRETCHED);
                layout.parent();
            }
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.orange, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
                layout.addFiller();
                layout.add(submitButton);
            }
        }

        // Put our layout contents into a JFrame.
        // getRoot() returns a reference to the top-most box in the layout.
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layout.getRoot(), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new OculusLayoutStretch();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
