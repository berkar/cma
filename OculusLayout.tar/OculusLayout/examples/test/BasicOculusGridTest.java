package test;

import javax.swing.*;
import java.awt.*;

import com.oculustech.layout.*;


public class BasicOculusGridTest {
    static public void main(String arg[]) {
        displayGUI();
    }


    // Try to build a common browser layout
    static public void displayGUI() {
        
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);
        
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addComponent(new JButton("Back"));
            layout.addComponent(new JButton("Forward"));
            JTextField text = new JTextField("dome://wine.oculustech.com");
            text.setMinimumSize(new Dimension(100, 19));
            layout.addComponent(text);
            layout.addComponent(new JButton("Stop"));
            layout.addComponent(new JButton("Home"));
            layout.parent();
        }
        
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addComponent(new Thing(20, 20, Color.blue));
            layout.addComponent(new JTextField("algebraic relation"));
            layout.addComponent(new JComboBox(new Object[]{"Public"}));
            layout.parent();
        }


        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.nestGrid(2,2);
            {
                layout.setJustification(OculusLayout.JUSTIFY_RIGHT);
                layout.add(new JLabel("Trigger"));
                layout.nestBox(OculusLayout.HORIZONTAL);
                {
                    layout.add(new JComboBox(new Object[]{"None"}));
                    layout.addFiller();
                    layout.add(new JButton("Execute"));
                    layout.parent();
                }
                layout.setJustification(OculusLayout.JUSTIFY_RIGHT);
                layout.add(new JLabel("Expression"));
                layout.add(new JTextField());
                layout.parent();
            }
            layout.parent();
        }
        
        show(layout.getRoot());
    }


    static public void show(JComponent j) {
        JFrame f = new JFrame();
        f.setContentPane(j);
        f.pack();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.show();
    }
}



class Thing extends JPanel {
    public Thing(int x, int y, Color c) {
        setPreferredSize(new Dimension(x, y));
        setBackground(c);
    }
}

