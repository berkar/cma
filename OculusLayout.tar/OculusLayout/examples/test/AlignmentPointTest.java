/*
 * AlignmentPointTest.java
 *
 * Created on February 6, 2001, 5:43 PM
 */

package test;

import com.oculustech.layout.*;

import java.awt.*;
import javax.swing.*;
/**
 * This class displays a simple layout with two rows, each with a labeled text field and a button.
 * The fields should be aligned with one another, even though the labels are
 * of different lengths.
 *
 * @author  jcmiller
 * @version 
 */
public class AlignmentPointTest extends javax.swing.JFrame {

    /** Creates new form AlignmentPointTest */
    public AlignmentPointTest() {
        initComponents ();
        pack ();
    }

    private void initComponents () {//GEN-BEGIN:initComponents
        JLabel label = new JLabel("My Field");
        JTextField field = new JTextField("Test Field");
        JButton button = new JButton("Test Button");

        JLabel label2 = new JLabel("My Other Field");
        JTextField field2 = new JTextField("Test Field 2");
        JButton button2 = new JButton("Test Button");

        addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
                exitForm (evt);
            }
        }
                           );



        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);
        layout.setDebugOutStream(System.err);
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.setDebugOutStream(System.err);
            layout.add(label);
            layout.addAlignmentPoint();
            layout.add(field);
            layout.add(button);
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.setDebugOutStream(System.err);
            layout.add(label2);
            layout.addAlignmentPoint();
            layout.add(field2);
            layout.add(button2);
            layout.parent();
        }
        
        getContentPane().setLayout(new OculusLayout(getContentPane(),OculusLayout.HORIZONTAL));
        getContentPane().add(layout.getRoot());
    }//GEN-END:initComponents

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit (0);
    }//GEN-LAST:event_exitForm

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new AlignmentPointTest ().show ();
    }
}
