package test;

import javax.swing.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import com.oculustech.layout.*;

public class GridBorderProblemTest extends JFrame {

    public GridBorderProblemTest() {
        super("OculusLayoutTutorial");

        //Create some components
        JLabel labelA = new JLabel("A");
        JLabel labelB = new JLabel("BB");
        JLabel labelC = new JLabel("CCC");
        JLabel postLabelA = new JLabel("feet");
        JLabel postLabelB = new JLabel("inches");
        JLabel postLabelC = new JLabel("meter");
        JTextField a = new JTextField(10);
        JTextField b = new JTextField(10);
        JTextField c = new JTextField(10);
        JButton foo = new JButton("foo");


        //Lay the components out
        OculusBox layoutPanel = new OculusBox(OculusLayout.HORIZONTAL);
        OculusLayoutHelper layout = new OculusLayoutHelper(layoutPanel);

        layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.blue, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.nestGrid(3, 3); //nest a grid
            {
                layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.red, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
                //right-justify the label so it is up against the textField
                layout.setGridCellJustification(OculusGrid.RIGHT_JUSTIFY,
                                            OculusGrid.DEFAULT_JUSTIFICATION);
                layout.add(labelA);
                layout.add(a);
                layout.add(postLabelA);
                //right-justify the label so it is up against the textField
                layout.setGridCellJustification(OculusGrid.RIGHT_JUSTIFY, OculusGrid.DEFAULT_JUSTIFICATION);
                layout.add(labelB);
                layout.add(b);
                layout.add(postLabelB);
                //right-justify the label so it is up against the textField
                layout.setGridCellJustification(OculusGrid.RIGHT_JUSTIFY, OculusGrid.DEFAULT_JUSTIFICATION);
                layout.add(labelC);
                layout.add(c);
                layout.add(postLabelC);
                layout.parent(); // pop out to the vertical box
            }
            //add filler to the box after the grid to push the grid to the top
            layout.addFiller();
            layout.parent(); //pop out to the horizontal box
        }
        layout.addSpace(25); //separate the components by 25 pixels
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.green, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            //add filler to the box first to push the button to the bottom
            layout.addFiller();
            layout.add(foo);
        }

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layoutPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new GridBorderProblemTest();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
