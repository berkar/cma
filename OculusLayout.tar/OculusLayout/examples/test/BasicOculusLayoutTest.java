/*
 * BasicOculusLayoutTest.java
 *
 * Created on February 6, 2001, 5:43 PM
 */

package test;

import com.oculustech.layout.*;

/**
 * This class displays a simple layout with a labeled list box, a column of
 * buttons, and a column with two titled border areas that respectively contain
 * a couple labels, and a couple textfields and labels.  The list box should
 * grow to consume all possible stretching.  The tops of the buttons and of the
 * top titled border should align with the top of the list box.
 *
 * @author  jcmiller
 * @version 
 */
public class BasicOculusLayoutTest extends javax.swing.JFrame {

    /** Creates new form BasicOculusLayoutTest */
    public BasicOculusLayoutTest() {
        initComponents ();
        pack ();
    }

    private void initComponents () {//GEN-BEGIN:initComponents
        LocalServerConfigLabel = new javax.swing.JLabel ();
        LocalServerList = new javax.swing.JList ();
        NewButton = new javax.swing.JButton ();
        DuplicateButton = new javax.swing.JButton ();
        DeleteButton = new javax.swing.JButton ();
        StopButton = new javax.swing.JButton ();
        HostNameLabel = new javax.swing.JLabel ();
        IPAddressLabel = new javax.swing.JLabel ();
        ServerNameLabel = new javax.swing.JLabel ();
        ServerNameTypeIn = new javax.swing.JTextField ();
        PortLabel = new javax.swing.JLabel ();
        PortTypeIn = new javax.swing.JTextField ();
        getContentPane ().setLayout (new java.awt.FlowLayout ());
        addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
                exitForm (evt);
            }
        }
                           );



        LocalServerConfigLabel.setName ("LocalServerConfigLabel");
        LocalServerConfigLabel.setText ("Local Server Configurations");

        NewButton.setText ("New");

        DuplicateButton.setText ("Duplicate");

        DeleteButton.setText ("Delete...");

        StopButton.setText ("Stop...");

        HostNameLabel.setText ("human-powered-floaters.ihpva.org");

        IPAddressLabel.setText ("(128.96.54.0 on eth0)");

        ServerNameLabel.setText ("Server Name:");

        ServerNameTypeIn.setText ("www.domesolutions.com");

        PortLabel.setText ("Port:");

        PortTypeIn.setText ("3363");

        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.HORIZONTAL);
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.addComponent(LocalServerConfigLabel);
            layout.addComponent(LocalServerList);
            layout.parent();
        }
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.alignNextComponentTo(LocalServerList,AlignedComponentSpacing.LEADING_EDGE,AlignedComponentSpacing.LEADING_EDGE);
            layout.addComponent(NewButton);
            layout.addComponent(DuplicateButton);
            layout.addComponent(DeleteButton);
            layout.addComponent(StopButton);
            layout.parent();
        }
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.alignNextComponentTo(NewButton,AlignedComponentSpacing.LEADING_EDGE,AlignedComponentSpacing.LEADING_EDGE);
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.addBorder("Hostname");
                layout.addComponent(HostNameLabel);
                layout.addComponent(IPAddressLabel);
                layout.parent();
            }
            layout.nestBox(OculusLayout.HORIZONTAL);
            {
                layout.addBorder("Configuration");
                layout.nestBox(OculusLayout.VERTICAL);
                {
                    layout.nestBox(OculusLayout.HORIZONTAL);
                    {
                        layout.addAlignmentSpacing();
                        layout.addComponent(ServerNameLabel);
                        layout.parent();
                    }
                    layout.addComponent(ServerNameTypeIn);
                    layout.parent();
                }
                layout.nestBox(OculusLayout.VERTICAL);
                {
                    layout.nestBox(OculusLayout.HORIZONTAL);
                    {
                        layout.addAlignmentSpacing();
                        layout.addComponent(PortLabel);
                        layout.parent();
                    }
                    layout.addComponent(PortTypeIn,OculusLayoutInfo.STRETCH_ONLY_TO_ALIGN,
                                        OculusLayoutInfo.NO_STRETCH);
                    layout.parent();
                }
                layout.parent();
            }
            layout.parent();
        }

        getContentPane().setLayout(new OculusLayout(getContentPane(),OculusLayout.HORIZONTAL));
        getContentPane().add(layout.getRoot());
    }//GEN-END:initComponents

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit (0);
    }//GEN-LAST:event_exitForm

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new BasicOculusLayoutTest ().show ();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LocalServerConfigLabel;
    private javax.swing.JList LocalServerList;
    private javax.swing.JButton NewButton;
    private javax.swing.JButton DuplicateButton;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton StopButton;
    private javax.swing.JLabel HostNameLabel;
    private javax.swing.JLabel IPAddressLabel;
    private javax.swing.JLabel ServerNameLabel;
    private javax.swing.JTextField ServerNameTypeIn;
    private javax.swing.JLabel PortLabel;
    private javax.swing.JTextField PortTypeIn;
    // End of variables declaration//GEN-END:variables

}
