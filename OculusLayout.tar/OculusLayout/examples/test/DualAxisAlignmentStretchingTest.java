/*
 * TestOculusLayout.java
 *
 * Created on February 6, 2001, 5:43 PM
 */

package test;

import com.oculustech.layout.*;

/**
 *
 * Makes a test layout that consists of a labeled list box in the upper left
 * that can stretch, a row of buttons stretching horizontally across the top
 * followed by a stretchable empty space.  
 *
 * The bottom half of the layout should contain another labeled list box, 
 * a button beneath it, and to its right two textfields and a button.  The
 * button, labeled "I'm Aligned" should have its left edge aligned with the
 * Duplicate button.  The top edge of the I'm Aligned button and its neighboring
 * textfields should be aligned with the bottom edge of the lower listbox.  The
 * lower list box can also stretch, as can both textfields, subject to the
 * constraints imposed on their respective positions.
 *
 * @author  jcmiller
 * @version 
 */
public class DualAxisAlignmentStretchingTest extends javax.swing.JFrame {

    /** Creates new form DualAxisAlignmentStretchingTest */
    public DualAxisAlignmentStretchingTest() {
        initComponents ();
        pack ();
    }

    private void initComponents () {//GEN-BEGIN:initComponents
        LocalServerConfigLabel = new javax.swing.JLabel ();
        LocalServerList = new javax.swing.JList ();
        OtherList = new javax.swing.JList ();
        NewButton = new javax.swing.JButton ();
        DuplicateButton = new javax.swing.JButton ();
        DeleteButton = new javax.swing.JButton ();
        StopButton = new javax.swing.JButton ();
        AlignedButton = new javax.swing.JButton ();
        HostNameLabel = new javax.swing.JLabel ();
        IPAddressLabel = new javax.swing.JLabel ();
        ServerNameLabel = new javax.swing.JLabel ();
        ServerNameTypeIn = new javax.swing.JTextField ();
        PortLabel = new javax.swing.JLabel ();
        PortTypeIn = new javax.swing.JTextField ();
        addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
                exitForm (evt);
            }
        }
                           );



        LocalServerConfigLabel.setName ("LocalServerConfigLabel");
        LocalServerConfigLabel.setText ("Local Server Configurations");

        NewButton.setText ("New Button");

        DuplicateButton.setText ("Duplicate");

        DeleteButton.setText ("Delete...");

        StopButton.setText ("Stop...");

        AlignedButton.setText("I'm Aligned");

        HostNameLabel.setText ("human-powered-floaters.ihpva.org");

        IPAddressLabel.setText ("(128.96.54.0 on eth0)");

        ServerNameLabel.setText ("Server Name:");

        ServerNameTypeIn.setText ("www.domesolutions.com");

        PortLabel.setText ("Port:");

        PortTypeIn.setText ("80");

        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.addComponent(LocalServerConfigLabel);
                layout.addComponent(LocalServerList);
                layout.parent();
            }
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.setDebugOutStream(System.err);
                layout.addAlignmentSpacing();
                layout.nestBox(OculusLayout.HORIZONTAL);
                {
                    layout.addComponent(NewButton);
                    layout.addComponent(DuplicateButton);
                    layout.addComponent(DeleteButton);
                    layout.addComponent(new Space(30,2),new OculusLayoutConstraints(OculusLayoutInfo.WANT_STRETCHED,OculusLayoutInfo.NO_STRETCH));
                    layout.parent();
                }
                layout.parent();
            }
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.addComponent(ServerNameLabel);
                layout.addComponent(OtherList);
                layout.addComponent(StopButton);
                layout.parent();
            }
            
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.setDebugOutStream(System.err);
                layout.alignNextComponentTo(OtherList,AlignedComponentSpacing.TRAILING_EDGE,AlignedComponentSpacing.LEADING_EDGE);
                layout.nestBox(OculusLayout.HORIZONTAL);
                {
                    layout.addComponent(PortTypeIn);
                    layout.alignNextComponentTo(DuplicateButton,AlignedComponentSpacing.LEADING_EDGE,AlignedComponentSpacing.LEADING_EDGE);
                    layout.addComponent(AlignedButton);
                    layout.addComponent(ServerNameTypeIn);
                    layout.parent();
                }
                layout.parent();
            }            

            layout.parent();
        }

        getContentPane().setLayout(new OculusLayout(getContentPane(),OculusLayout.HORIZONTAL));
        getContentPane().add(layout.getRoot());
    }

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit (0);
    }

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new DualAxisAlignmentStretchingTest ().show ();
    }


    private javax.swing.JLabel LocalServerConfigLabel;
    private javax.swing.JList LocalServerList;
    private javax.swing.JList OtherList;
    private javax.swing.JButton NewButton;
    private javax.swing.JButton DuplicateButton;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton StopButton;
    private javax.swing.JButton AlignedButton;
    private javax.swing.JLabel HostNameLabel;
    private javax.swing.JLabel IPAddressLabel;
    private javax.swing.JLabel ServerNameLabel;
    private javax.swing.JTextField ServerNameTypeIn;
    private javax.swing.JLabel PortLabel;
    private javax.swing.JTextField PortTypeIn;
}
