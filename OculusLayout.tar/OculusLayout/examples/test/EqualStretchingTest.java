/*
 * EqualStretchingTest.java
 *
 * Created on February 6, 2001, 5:43 PM
 */

package test;

import com.oculustech.layout.*;

import java.awt.*;
import javax.swing.*;
/**
 * This class displays a simple layout with three side-by-side text fields,
 * which should all be equally stretched.
 *
 * @author  jcmiller
 * @version 
 */
public class EqualStretchingTest extends javax.swing.JFrame {

    /** Creates new form EqualStretchingTest */
    public EqualStretchingTest() {
        initComponents ();
        pack ();
    }

    private void initComponents () {//GEN-BEGIN:initComponents
        JTextField field = new JTextField("Test Field");
        JTextField field2 = new JTextField("Test Field");
        JTextField field3 = new JTextField("Test Field");

        addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
                exitForm (evt);
            }
        });

        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.setDebugOutStream(System.out);
            layout.setLayoutHelperDebugOutStream(System.out);

            layout.add(field);
            layout.add(field2);
            layout.add(field3);
            layout.parent();
        }

        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            // this should force equal stretching
            layout.addSpace(790);
            layout.parent();
        }
        setContentPane(layout.getRoot());
    }//GEN-END:initComponents

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit (0);
    }//GEN-LAST:event_exitForm

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new EqualStretchingTest ().show ();
    }
}
