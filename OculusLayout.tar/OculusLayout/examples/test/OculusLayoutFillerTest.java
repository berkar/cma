/*
 * OculusLayoutFillerTest.java
 *
 * Created on February 6, 2001, 5:43 PM
 */

package test;

import com.oculustech.layout.*;

import java.awt.*;
import javax.swing.*;
/**
 * @author  jcmiller
 * @version 
 */
public class OculusLayoutFillerTest extends javax.swing.JFrame {

    /** Creates new form OculusLayoutFillerTest */
    public OculusLayoutFillerTest() {
        initComponents ();
        pack ();
    }

    private void initComponents () {//GEN-BEGIN:initComponents
        JButton button = new JButton("Test Button");
        JButton button2 = new JButton("Test Button");
        JButton button3 = new JButton("Test Button");
        JButton button4 = new JButton("Test Button");
        JButton button5 = new JButton("Test Button");
        JButton button6 = new JButton("Test Button");

        addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
                exitForm (evt);
            }
        }
                           );



        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.HORIZONTAL);
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.add(button);
            layout.add(button2);
            layout.add(button3);
            layout.parent();
        }
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.addFiller();
            layout.nestBox(OculusLayout.HORIZONTAL);
            {
                layout.addFiller();
                layout.add(button4);
                layout.addFiller();
                layout.parent();
            }
            layout.nestBox(OculusLayout.HORIZONTAL);
            {
                layout.add(button5);
                layout.addFiller();
                layout.add(button6);
                layout.parent();
            }
            layout.parent();
        }        
        getContentPane().setLayout(new OculusLayout(getContentPane(),OculusLayout.HORIZONTAL));
        getContentPane().add(layout.getRoot());
    }//GEN-END:initComponents

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit (0);
    }//GEN-LAST:event_exitForm

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new OculusLayoutFillerTest ().show ();
    }
}
