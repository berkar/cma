package test;

import com.oculustech.layout.*;

import java.awt.*;
import javax.swing.*;
/**
 * This class displays a simple layout with two rows in a grid, and a button
 * at the bottom.  Each grid row consists of a label, and some text.  The
 * first line has a single JTextField as its text.  The second line has a
 * JTextArea as its text, with line wrapping enabled.  The window should come
 * up displaying the whole of the text without cutting anything off.
 *
 * This test fails.  There is a bug in swing that causes this to be an
 * impossible test case to make work properly.  Either the layout system goes
 * into an infinite loop due to swing dumbness, or it puts up with the text area
 * not shrinking itself properly.  -JCM 4/5/02
 *

 * @author  jcmiller
 * @version 
 */
public class JTextAreaTest extends javax.swing.JFrame {

    /** Creates new form JTextAreaTest */
    public JTextAreaTest() {
        initComponents ();
        pack ();
    }

    private void initComponents () {//GEN-BEGIN:initComponents
        JLabel label = new JLabel("Line 1");
        JTextField field = new JTextField("This is a sentence that goes on for many characters so as to be wide.");
        field.setEditable(false);
        JLabel label2 = new JLabel("Multi-line");
        JTextArea field2 = new JTextArea("To be, or not to be, that is the question.  Whether 'tis nobler in the mind to suffer the slings and arrows of outrageous fortune, or to take up arms against a sea of troubles, and by opposing, end them.  To die.  To sleep, no more.  And by a sleep, to say we end the heartache, and the thousand natural shocks that flesh is heir to; 'tis a consummation devoutly to be wished.  To die, to sleep -- To sleep, perchance to dream.  Aye, there's the rub!  For in that sleep of death what dreams may come, when we have shuffled off this mortal coil, must give us pause.");
        field2.setLineWrap(true);
        field2.setEditable(false);
        field2.setColumns(80);
        field2.setWrapStyleWord(true);
        JScrollPane jsp = new JScrollPane(field2);
        jsp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);

        JButton button = new JButton("Test Button");
        
        addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
                exitForm (evt);
            }
        });


        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);
        layout.nestGrid(2,2);
        {
            layout.add(label);
            layout.add(field);
            layout.add(label2);
            layout.add(field2);
            //layout.add(jsp);
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addAlignmentSpacing();
            layout.add(button);
            layout.parent();
        }
        
        getContentPane().setLayout(new OculusLayout(getContentPane(),OculusLayout.HORIZONTAL));
        getContentPane().add(layout.getRoot());
    }//GEN-END:initComponents

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit (0);
    }//GEN-LAST:event_exitForm

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new JTextAreaTest ().show ();
    }
}
