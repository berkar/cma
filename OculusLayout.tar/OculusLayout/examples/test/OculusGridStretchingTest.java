package test;

import javax.swing.*;
import java.awt.*;

import com.oculustech.layout.*;


public class OculusGridStretchingTest {
    static public void main(String arg[]) {
        displayGUI();
    }


    // Try to build a common browser layout
    static public void displayGUI() {
        
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);
        
        layout.nestGrid(3,3);
        {
            layout.setDebugOutStream(System.out);
            Component s = layout.add(new
                                     Space(50,50,20,20,1000000,1000000),OculusLayout.WANT_STRETCHED,OculusLayout.WANT_STRETCHED);
            s.setBackground(Color.white);
            layout.add(new JScrollBar(JScrollBar.VERTICAL));
            layout.addSpace(1);

            layout.add(new JScrollBar(JScrollBar.HORIZONTAL));
            layout.addSpace(1);
            layout.addSpace(1);

            layout.addSpace(1);
            layout.addSpace(1);
            layout.addSpace(1);

            layout.parent();
        }

        show(layout.getRoot());
    }


    static public void show(JComponent j) {
        JFrame f = new JFrame();
        f.setContentPane(j);
        f.pack();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.show();
    }
}



