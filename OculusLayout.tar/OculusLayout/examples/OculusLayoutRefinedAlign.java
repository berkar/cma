/*
 * Oculus Layout Tutorial
 */

import javax.swing.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import com.oculustech.layout.*;

public class OculusLayoutRefinedAlign extends JFrame {

    public OculusLayoutRefinedAlign() {
        super("OculusLayoutTutorial");

        // Create some components
        JLabel mainLabel = new JLabel("These are Inputs");
        JLabel labelB = new JLabel("BB");
        JLabel labelC = new JLabel("CCC");
        JLabel postLabelB = new JLabel("in");
        JLabel postLabelC = new JLabel("m");
        JLabel postLabelC2 = new JLabel("km");
        JLabel orLabel = new JLabel(" OR ");
        JTextField bField = new JTextField(10);
        JTextField cField = new JTextField(10);
        JTextField c2Field = new JTextField(10);
        JCheckBox round = new JCheckBox("round");
        JButton submitButton = new JButton("Submit");


        // Lay the components out.  The top-level box will be vertically
        // oriented.
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);

        layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.blue, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
        // By default, the main vertical box would be left-justified.  This
        // will center its components.
        layout.setJustification(OculusLayout.JUSTIFY_CENTER);
        layout.add(mainLabel);
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.add(labelB);
            // Step 2: add alignment points before and after the text field,
            // and before the check box.  These points will only affect the
            // layout in conjunction with alignment points in another box.
            layout.addAlignmentPoint(); // Step 2: 1st point in cyan box
            layout.add(bField);
            layout.addAlignmentPoint(); // Step 2: 2nd point in cyan box
            layout.add(postLabelB);
            layout.addAlignmentPoint(); // Step 2: 3rd point in cyan box
            layout.add(round);
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.red, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.add(labelC);
            // Step 2: These first two alignment points will align the
            // beginnings and ends, respectively, of the text fields in this
            // box with those in the previous horizontal box.
            layout.addAlignmentPoint(); // Step 2: 1st point in red box
            layout.add(cField);
            layout.addAlignmentPoint(); // Step 2: 2nd point in red box
            layout.add(postLabelC);
            layout.add(orLabel);
            // Step 2: This third alignment point will align the check box
            // with the right-most text field.
            layout.addAlignmentPoint(); // Step 2: 3rd point in red box
            layout.add(c2Field);
            layout.add(postLabelC2);
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.green, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.addFiller();
            // Step 3: Align the beginning (leading edge) of the submit button
            // with the end (trailing edge) of mainLabel
            layout.alignNextComponentTo(mainLabel, AlignedComponentSpacing.TRAILING_EDGE, AlignedComponentSpacing.LEADING_EDGE);
            layout.add(submitButton);
            layout.addFiller();
        }

        // Put our layout contents into a JFrame.
        // getRoot() returns a reference to the top-most box in the layout.
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layout.getRoot(), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new OculusLayoutRefinedAlign();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
