/*
 * Oculus Layout Tutorial
 */

import javax.swing.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import com.oculustech.layout.*;

public class OculusLayoutGrid extends JFrame {

    public OculusLayoutGrid() {
        super("OculusLayoutTutorial");

        // Create some components
        JLabel mainLabel = new JLabel("Inputs");
        JLabel labelA = new JLabel("A");
        JLabel labelB = new JLabel("BB");
        JLabel labelC = new JLabel("CCC");
        JLabel postLabelA = new JLabel("ft");
        JLabel postLabelB = new JLabel("in");
        JLabel postLabelC = new JLabel("m");
        JLabel postLabelC2 = new JLabel("km");
        JLabel orLabel = new JLabel(" OR ");
        JTextField a = new JTextField(10);
        JTextField b = new JTextField(10);
        JTextField c = new JTextField(10);
        JTextField c2 = new JTextField(10);
        JCheckBox round = new JCheckBox("round");


        // Lay the components out.  The top-level box will be vertically
        // oriented.
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);

        // Add an outer border to the layout
        layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.blue, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
        layout.add(mainLabel);
        layout.nestGrid(4, 3); // Nest a grid with 4 columns and 3 rows
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            // Now components are added to the nested grid, starting with the
            // top row, from left to right.
            layout.add(labelA);
            layout.add(a);
            layout.add(postLabelA);
            // A Space is added to the fourth cell in the top row just to fill
            // the spot and move the cursor along.
            layout.addSpace(5);
            // After the four cells in the top row are filled, the cursor
            // position automatically shifts to the beginning of the second
            // row down.
            layout.add(labelB);
            layout.add(b);
            layout.add(postLabelB);
            layout.add(round);
            // And now the third row...
            layout.add(labelC);
            layout.add(c);
            layout.add(postLabelC);
            // The fourth component in the bottom row is itself a nested box.
            layout.nestBox(OculusLayout.HORIZONTAL);
            {
                layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.red, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
                layout.add(orLabel);
                layout.add(c2);
                layout.add(postLabelC2);
            }
        }

        // Put our layout contents into a JFrame.
        // getRoot() returns a reference to the top-most box in the layout.
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layout.getRoot(), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new OculusLayoutGrid();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
