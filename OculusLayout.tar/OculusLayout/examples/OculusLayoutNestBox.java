/*
 * Oculus Layout Tutorial
 */

import javax.swing.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import com.oculustech.layout.*;

public class OculusLayoutNestBox extends JFrame {

    public OculusLayoutNestBox() {
        super("OculusLayoutTutorial");

        // Set the license key
        //OculusLayout.setLicenseNumber("Your license key here");

        // Create some components
        JLabel fileLabel = new JLabel("File");
        JTextField file = new JTextField(10);
        JButton fileButton = new JButton("Select");
        JLabel displayLabel = new JLabel("Display File");
        JTextArea display = new JTextArea("File contents here.");


        // Lay the components out.  The top-level box will be vertically
        // oriented.
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.VERTICAL);

        // Add an outer border to the layout
        layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.blue, 3), BorderFactory.createEmptyBorder(5,5,5,5)));

        // Nest a horizontal box in the current cursor position as the first
        // component
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            // Now components are added to the nested horizontal box
            layout.add(fileLabel);
            layout.add(file);
            layout.add(fileButton);
            layout.parent(); // Pop out to the vertical box
        }
        // Now components are added to the vertical box following the nested 
        // horizontal box
        layout.add(displayLabel);
        layout.add(display);

        // Put our layout contents into a JFrame.
        // getRoot() returns a reference to the top-most box in the layout.
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layout.getRoot(), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new OculusLayoutNestBox();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
