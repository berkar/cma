/*
 * Oculus Layout Tutorial
 */

import javax.swing.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import com.oculustech.layout.*;

public class OculusLayoutSimpleAlign extends JFrame {

    public OculusLayoutSimpleAlign() {
        super("OculusLayoutTutorial");

        // Create some components
        JLabel labelA = new JLabel("A");
        JLabel labelB = new JLabel("BB");
        JLabel labelC = new JLabel("CCC");
        JLabel postLabelA = new JLabel("ft");
        JLabel postLabelB = new JLabel("in");
        JLabel postLabelC = new JLabel("m");
        JTextField a = new JTextField(10);
        JTextField b = new JTextField(10);
        JTextField c = new JTextField(10);
        JButton foo = new JButton("foo");


        // Lay the components out.  The top-level box will be horizontally
        // oriented.
        OculusLayoutHelper layout = new OculusLayoutHelper(OculusLayout.HORIZONTAL);

        layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.blue, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            layout.nestGrid(3, 3); //nest a grid
            {
                layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.red, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
                // Right-justify the label so it is up against the text
                // field.  This is the first component in the top row.
                layout.setGridCellJustification(OculusGrid.RIGHT_JUSTIFY,
                                            OculusGrid.DEFAULT_JUSTIFICATION);
                layout.add(labelA);
                layout.add(a);
                layout.add(postLabelA);
                // Right-justify the label so it is up against the text
                // field.  This is the first component in the middle row.
                layout.setGridCellJustification(OculusGrid.RIGHT_JUSTIFY, OculusGrid.DEFAULT_JUSTIFICATION);
                layout.add(labelB);
                layout.add(b);
                layout.add(postLabelB);
                // Right-justify the label so it is up against the text
                // field.  This is the first component in the bottom row.
                layout.setGridCellJustification(OculusGrid.RIGHT_JUSTIFY, OculusGrid.DEFAULT_JUSTIFICATION);
                layout.add(labelC);
                layout.add(c);
                layout.add(postLabelC);
                layout.parent(); // Pop out to the vertical box
            }
            // Add filler to the vertical box after the grid to push the grid
            // to the top.  By default, the grid would be centered in the
            // vertical axis.
            layout.addFiller();
            layout.parent(); // Pop out to the horizontal box
        }
        // Separate the preceding vertical box and the following vertical box
        // by 25 pixels
        layout.addSpace(25);
        layout.nestBox(OculusLayout.VERTICAL);
        {
            layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.green, 3), BorderFactory.createEmptyBorder(5,5,5,5)));
            // Add filler to the vertical box first to push the button to the
            // bottom
            layout.addFiller();
            layout.add(foo);
        }

        // Put our layout contents into a JFrame.
        // getRoot() returns a reference to the top-most box in the layout.
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layout.getRoot(), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new OculusLayoutSimpleAlign();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
