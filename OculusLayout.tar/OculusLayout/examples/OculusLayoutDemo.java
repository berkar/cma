/*
 * Swing Version
 */

import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events

import java.io.IOException;

import com.oculustech.layout.*;

public class OculusLayoutDemo extends JFrame {

    public OculusLayoutDemo() {
        super("OculusLayoutDemo");

        OculusBox layoutPanel;
        OculusLayoutHelper layout;
        

        //Create a regular text field.
        JTextField unameField = new JTextField(10);

        //Create a password field.
        JPasswordField passwordField = new JPasswordField(10);

        //Create a email field
        JTextField email = new JTextField(15);

        //Create some labels for the fields.
        JLabel unameLabel = new JLabel("Username");
        JLabel passwordLabel = new JLabel("Password");
        JLabel emailLabel = new JLabel("Email Address");

        //Create a checkbox for email yes/no
        JCheckBox emailCheck = new JCheckBox("Send me lots of email");

        //Create the notes section
        JTextArea notes = new JTextArea("put your own notes here.");
        JScrollPane notesScrollPane = new JScrollPane(notes);
        notesScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        //Create the instructions area
        JTextArea instructions = new JTextArea("Comments and instructions go here.");
        instructions.setEditable(false);

        //Create some labels for the areas
        JLabel notesLabel = new JLabel("Notes");
        JLabel instrLabel = new JLabel("Instructions");

        //Create the filepath
        JTextField absFilePath = new JTextField(30);
        JLabel filepathLabel = new JLabel("Filepath");

        //Create the file button
        JButton fileButton = new JButton("Select file...");


        //start laying out on the panel
        layoutPanel = new OculusBox(OculusLayout.VERTICAL);
        layout = new OculusLayoutHelper(layoutPanel);

        layout.addBorder(BorderFactory.createEmptyBorder(7,7,7,7));
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.nestBox(OculusLayout.HORIZONTAL);
                {
                    layout.nestGrid(2,3);
                    {
                        layout.add(unameLabel);
                        layout.add(unameField);
                        layout.add(passwordLabel);
                        layout.add(passwordField);
                        layout.add(emailLabel);
                        layout.add(email);
                        layout.parent();
                    }
                    layout.nestBox(OculusLayout.VERTICAL);
                    {
                        layout.addFiller();
                        layout.add(emailCheck);
                        layout.parent();
                    }
                    layout.addBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.darkGray),BorderFactory.createEmptyBorder(5,5,5,5)));
                    layout.parent();
                }
                layout.addSpace(10);
                layout.add(notesLabel);
                layout.add(notesScrollPane);
                layout.parent();
            }
            layout.addSpace(10);
            layout.nestBox(OculusLayout.VERTICAL);
            {
                layout.add(instrLabel);
                layout.add(instructions);
                layout.parent();
            }
            layout.parent();
        }
        layout.nestBox(OculusLayout.HORIZONTAL);
        {
            layout.add(filepathLabel);
            layout.add(absFilePath);
            layout.add(fileButton);
        }

        //finish it off
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(layoutPanel, BorderLayout.CENTER);
    }

    // public void actionPerformed(ActionEvent e) {
    //}

    public static void main(String[] args) {
        JFrame frame = new OculusLayoutDemo();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}




