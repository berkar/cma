***************************************************************************
***********        Oculus Layout API & Builder        *********************
***************************************************************************

Getting Started:
  
  Welcome to the Oculus Layout System for the Java Platform.  The
  Oculus Layout System makes it easy to create sophisticated,
  stretchable layouts of components in your Swing and/or AWT
  applications.  The System consists of two parts: The graphical
  builder, and the layout API.  The builder is an application that
  lets you visually build your layouts using drag-and-drop.  The
  layout API contains the LayoutManagers, containers, and other
  primitives for use from your code in laying out your widgets.

  The Oculus Layout System requires that you have a Java JDK
  or JRE installed on your system.  The Oculus Layout System is 100%
  Java, and has been tested to run with JDK/JRE versions 1.3.x and
  1.4.

  To get started with the OculusLayout system, we suggest you do the
  following:

  1.  Go through the Builder tutorial.  This will let you quickly get
      a feel for how the Oculus Layout paradigm works, and see it in
      action.

  2.  Generate code for a layout from the builder.  Read through the
      code; note how straightforward it is.  Imagine doing the same
      layout using GridBagLayout!

  3.  Go through the Layout API tutorial.  This will explain the
      basics of using the Layout API from handwritten code, and will
      give you the background you need to edit and change
      builder-generated code.  

  4.  Read the javadocs for the Layout API, starting with those for
      the OculusLayoutHelper class, which is the chief class used in
      creating layouts with the Oculus Layout System.  

Tutorials:

  help/OculusLayoutAPI-Tutorial.pdf covers using the Oculus Layout API
  for layout from within your code.

  help/OculusLayoutBuilder-Tutorial.pdf covers using the builder to
  generate code for easy-to-read, human-editable GUI layouts that use
  the Oculus Layout API.  

Javadocs:

  javadocs/OculusLayoutAPI/index.html documents the OculusLayoutAPI.  
  
  javadocs/BuilderPluginAPI/index.html documents the process of adding 
  your own custom components into the builder via its plugin API.  
  For examples of this, see the exampleplugins/ directory.

The Builder:

  The graphical Builder lets you quickly design Swing GUIs, and then
  generates easy-to-read human-editable code that implements the
  layouts using the Oculus Layout APIs.  For a tutorial on using the
  builder, see help/OculusLayoutBuilder-Tutorial.pdf.

Launching the Builder:

  Windows users can launch the Builder from the shortcut in their
  Start menu.

  On other platforms, run the builder by executing the
  LayoutBuilder.jar file with Java.  Depending on the platform, you
  may be able to double-click on the .jar file to do this, or you can
  use the following command line syntax:

    java -jar LayoutBuilder.jar

  Note that the LayoutBuilder requires a Java JRE or JDK 1.3 or higher
  be installed on your machine.  You can download the latest JRE or
  JDK free of charge from Sun at http://www.javasoft.com/

Compiling/Linking:

  All code that uses the OculusLayout API must be compiled against and
  distributed with the OculusLayout.jar.  This jar is freely redistributable
  as an internal part of a product by purchasers of this system.  See
  the product license for full details.

  You can use the Builder to build layouts, and by turning off Edit
  mode (via the Edit mode option in the View menu), you will see
  exactly the same layout you would when the generated code is linked
  against the OculusLayout library.  You can also generate the source
  code, and see for yourself how simple even the most complex layouts
  are when done with the Oculus Layout system.

Demo Mode
  
  When the OculusLayout system is in demo mode, any of your
  applications that call into the OculusLayout API library will have
  'nag' pop-up dialogs appear regularly, reminding users that the
  program is using an unlicensed copy of Oculus Layout.  To turn off
  the nag dialogs, be sure that your program sets a license number for
  the library.

Purchasing

  You can purchase a license for the OculusLayout system from
  http://www.javalayout.com/

  Once you have purchased a license, you will need to put the
  following call into the main routine of your applications:

    OculusLayout.setLicenseNumber("Your License Number Here");

  This will turn off the demo-mode nag dialogs.  

